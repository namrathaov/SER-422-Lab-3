package client.tempuri;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Method extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Method() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<HTML><HEAD><TITLE>Methods</TITLE></HEAD>"
				+ "<BODY><H1>Methods</H1><UL><LI>"
				+ "<A HREF=Input?method=2 TARGET=inputs> getEndpoint()</A></LI>"
				+ "<LI><A HREF=Input?method=5 TARGET=inputs> setEndpoint(java.lang.String)</A></LI>"
				+ "<LI><A HREF=Input?method=10 TARGET=inputs> getIService()</A></LI>"
				+ "<LI><A HREF=Input?method=13 TARGET=inputs> getWeather(java.lang.String,java.lang.String)</A></LI>"
				+ "<LI><A HREF=Input?method=20 TARGET=inputs> getWeather_hourly(java.lang.String,java.lang.String,java.lang.Boolean)</A></LI>"
				+ "<LI><A HREF=Input?method=29 TARGET=inputs> getWeather_tenDays(java.lang.String,java.lang.String,java.lang.Boolean)"
						+ "</A></LI></UL></BODY></HTML>");
	}	
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<HTML><HEAD><TITLE>Methods</TITLE></HEAD>"
				+ "<BODY><H1>Methods</H1><UL><LI>"
				+ "<A HREF=Input?method=2 TARGET=inputs> getEndpoint()</A></LI>"
				+ "<LI><A HREF=Input?method=5 TARGET=inputs> setEndpoint(java.lang.String)</A></LI>"
				+ "<LI><A HREF=Input?method=10 TARGET=inputs> getIService()</A></LI>"
				+ "<LI><A HREF=Input?method=13 TARGET=inputs> getWeather(java.lang.String,java.lang.String)</A></LI>"
				+ "<LI><A HREF=Input?method=20 TARGET=inputs> getWeather_hourly(java.lang.String,java.lang.String,java.lang.Boolean)</A></LI>"
				+ "<LI><A HREF=Input?method=29 TARGET=inputs> getWeather_tenDays(java.lang.String,java.lang.String,java.lang.Boolean)"
						+ "</A></LI></UL></BODY></HTML>");
	}

}
