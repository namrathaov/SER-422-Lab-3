package client.tempuri;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.tempuri.IServiceProxy;
public class Result extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		
		}
		public void doPost(HttpServletRequest request, HttpServletResponse response)
				throws ServletException, IOException 
		{
			PrintWriter out = response.getWriter();
			response.setContentType("text/html");
			IServiceProxy clientIServiceProxy = new IServiceProxy();
			/*	if (request.getParameter("endpoint") != null && request.getParameter("endpoint").length() > 0)
				clientIServiceProxy.setEndpoint(request.getParameter("endpoint"));
			 */
			if(request.getParameter("Invoke").contains("Invoke")) {
				String method = (String) request.getParameter("method");
				System.out.print(method);
				int methodID = 0;
				if (method.equals(null))
					methodID = -1;
				System.out.println(method);
				if(methodID != -1) methodID = Integer.parseInt(method);
				System.out.println(methodID);
				
				boolean gotMethod = false;
				String city_name=  request.getParameter("city_name");
				String state_name=  request.getParameter("state_name");
				String getWeather;
				System.out.println(city_name + " "+ state_name);
				try {
					if(methodID==1) {
						gotMethod = true;
						if(!city_name.equals("") && (!state_name.equals(""))){
							getWeather = clientIServiceProxy.getWeather(city_name,state_name);
							if(getWeather != null){
								
								out.print(getWeather);
							}else{
								out.print("Weather for "+city_name +" and "+state_name+ " not found");
							}
						}
					}
						if(methodID==2) {
							gotMethod = true;
							String hourly=  request.getParameter("hourly");
							if(hourly.equals("true")) {
							String getWeather_hourly = clientIServiceProxy.getWeather_hourly(city_name,state_name,true);
							if(getWeather_hourly != null){
								out.print(getWeather_hourly);

							}else{
								out.print("Hourly Weather for "+city_name +" and "+state_name+ " not found");
							}
						}
						}
						if(methodID==3) {
							gotMethod = true;
							String tenday=  request.getParameter("tenDays");
							if(tenday.equals("true")){
								String getWeather_tenDays = clientIServiceProxy.getWeather_tenDays(city_name,state_name,true);
							if(getWeather_tenDays != null){
								out.print(getWeather_tenDays);
							}else{
								out.print("Ten Day Weather for "+city_name +" and "+state_name+ " not found");
							}

						}
						}
						}
						catch (Exception e) { 
							e.printStackTrace();
							out.print("Method not found "+city_name +" and "+state_name+ " not found");
					}
					if(!gotMethod){
						out.print("NA");
					}   
					System.out.print("true");
				}
			/*HttpSession session = request.getSession();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		IServiceProxy clientIServiceProxyid = new IServiceProxy();
		if (request.getParameter("endpoint") != null && request.getParameter("endpoint").length() > 0)
			clientIServiceProxyid.setEndpoint(request.getParameter("endpoint"));
		System.out.println("MethodID: " +request.getParameter("method"));
		String method = request.getParameter("method");
		int methodID = 0;
		if (method == null) methodID = -1;

		if(methodID != -1) methodID = Integer.parseInt(method);
		boolean gotMethod = false;

		try {
		switch (methodID){ 
		case 2:
		        gotMethod = true;
		        java.lang.String getEndpoint2mtemp = clientIServiceProxyid.getEndpoint();
		if(getEndpoint2mtemp == null){
			out.print(getEndpoint2mtemp);
	}
		else {
		        String tempResultreturnp3 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(getEndpoint2mtemp));
		        out.print(tempResultreturnp3);
		}
		break;
		case 5:
		        gotMethod = true;
		        String endpoint_0id=  request.getParameter("endpoint8");
		            java.lang.String endpoint_0idTemp = null;
		        if(!endpoint_0id.equals("")){
		         endpoint_0idTemp  = endpoint_0id;
		        }
		        clientIServiceProxyid.setEndpoint(endpoint_0idTemp);
		break;
		case 10:
		        gotMethod = true;
		        org.tempuri.IService getIService10mtemp = clientIServiceProxyid.getIService();
		if(getIService10mtemp == null){
			out.print("getIService10mtemp ");
		}else{
		        if(getIService10mtemp!= null){
		        String tempreturnp11 = getIService10mtemp.toString();
		        out.print(tempreturnp11);
		        }}
		break;
		case 13:
		        gotMethod = true;
		        String city_name_1id=  request.getParameter("city_name16");
		            java.lang.String city_name_1idTemp = null;
		        if(!city_name_1id.equals("")){
		         city_name_1idTemp  = city_name_1id;
		        }
		        String state_name_2id=  request.getParameter("state_name18");
		            java.lang.String state_name_2idTemp = null;
		        if(!state_name_2id.equals("")){
		         state_name_2idTemp  = state_name_2id;
		        }
		        java.lang.String getWeather13mtemp = clientIServiceProxyid.getWeather(city_name_1idTemp,state_name_2idTemp);
		if(getWeather13mtemp == null){
			out.print(getWeather13mtemp);
		}else{
		        String tempResultreturnp14 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(getWeather13mtemp));
		        out.print(tempResultreturnp14);
		}
		break;
		case 20:
		        gotMethod = true;
		        String city_name_3id=  request.getParameter("city_name23");
		            java.lang.String city_name_3idTemp = null;
		        if(!city_name_3id.equals("")){
		         city_name_3idTemp  = city_name_3id;
		        }
		        String state_name_4id=  request.getParameter("state_name25");
		            java.lang.String state_name_4idTemp = null;
		        if(!state_name_4id.equals("")){
		         state_name_4idTemp  = state_name_4id;
		        }
		        String hourly_5id=  request.getParameter("hourly27");
		            java.lang.Boolean hourly_5idTemp = null;
		        if(!hourly_5id.equals("")){
		         hourly_5idTemp  = java.lang.Boolean.valueOf(hourly_5id);
		        }
		        java.lang.String getWeather_hourly20mtemp = clientIServiceProxyid.getWeather_hourly(city_name_3idTemp,state_name_4idTemp,hourly_5idTemp);
		if(getWeather_hourly20mtemp == null){
			out.print(getWeather_hourly20mtemp);

		}else{
		        String tempResultreturnp21 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(getWeather_hourly20mtemp));
		        out.print(tempResultreturnp21);
		}
		break;
		case 29:
		        gotMethod = true;
		        String city_name_6id=  request.getParameter("city_name32");
		            java.lang.String city_name_6idTemp = null;
		        if(!city_name_6id.equals("")){
		         city_name_6idTemp  = city_name_6id;
		        }
		        String state_name_7id=  request.getParameter("state_name34");
		            java.lang.String state_name_7idTemp = null;
		        if(!state_name_7id.equals("")){
		         state_name_7idTemp  = state_name_7id;
		        }
		        String tenday_8id=  request.getParameter("tenday36");
		            java.lang.Boolean tenday_8idTemp = null;
		        if(!tenday_8id.equals("")){
		         tenday_8idTemp  = java.lang.Boolean.valueOf(tenday_8id);
		        }
		        java.lang.String getWeather_tenDays29mtemp = clientIServiceProxyid.getWeather_tenDays(city_name_6idTemp,state_name_7idTemp,tenday_8idTemp);
		if(getWeather_tenDays29mtemp == null){
			out.print(getWeather_tenDays29mtemp);
		}else{
		        String tempResultreturnp30 = org.eclipse.jst.ws.util.JspUtils.markup(String.valueOf(getWeather_tenDays29mtemp));
		        out.print(tempResultreturnp30);
		}
		break;
		}
		} catch (Exception e) { 
			out.print(org.eclipse.jst.ws.util.JspUtils.markup(e.toString()));
			out.print(org.eclipse.jst.ws.util.JspUtils.markup(e.getMessage()));
			return;
		}
		if(!gotMethod){
			out.print("NA");
			}*/
		}
	}