package client.tempuri;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Index extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<HTML><HEAD><TITLE>Methods</TITLE></HEAD>"
				+ "<BODY><H1>Methods</H1><UL>"
				+ "<LI><A HREF=Input?method=1> getWeather(String,String)</A></LI>"
				+ "<LI><A HREF=Input?method=2> getWeather_hourly(String,String,Boolean)</A></LI>"
				+ "<LI><A HREF=Input?method=3> getWeather_tenDays(String,String,Boolean)"
						+ "</A></LI></UL></BODY></HTML>");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
}
