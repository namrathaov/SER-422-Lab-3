package client.tempuri;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TestClient
 */
public class TestClient extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TestClient() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<HTML><HEAD><TITLE>Web Services Test Client</TITLE></HEAD><FRAMESET  COLS=220,*>"
				+ "<FRAME SRC=Method NAME=methods MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>"
		+"<FRAMESET  ROWS=80%,20%>"
				+ "<FRAME SRC=Input NAME=inputs  MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>");
		StringBuffer resultJSP = new StringBuffer("Result");
		resultJSP.append("?");
		java.util.Enumeration resultEnum = request.getParameterNames();
		while (resultEnum.hasMoreElements()) {
		Object resultObj = resultEnum.nextElement();
		resultJSP.append(resultObj.toString()).append("=").append(request.getParameter(resultObj.toString())).append("&");
		}
		out.print("<FRAME SRC="+org.eclipse.jst.ws.util.JspUtils.markup(resultJSP.toString()) +"NAME=result  MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>"
        +"</FRAMESET><NOFRAMES><BODY>The Web Services Test Client requires a browser that supports frames.</BODY>"
		+"</NOFRAMES></FRAMESET></HTML>");
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.print("<HTML><HEAD><TITLE>Web Services Test Client</TITLE></HEAD><FRAMESET  COLS=220,*>"
				+ "<FRAME SRC=Method NAME=methods MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>"
		+"<FRAMESET  ROWS=80%,20%>"
				+ "<FRAME SRC=Input NAME=inputs  MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>");
		StringBuffer resultJSP = new StringBuffer("Result");
		resultJSP.append("?");
		java.util.Enumeration resultEnum = request.getParameterNames();
		while (resultEnum.hasMoreElements()) {
		Object resultObj = resultEnum.nextElement();
		resultJSP.append(resultObj.toString()).append("=").append(request.getParameter(resultObj.toString())).append("&");
		}
		out.print("<FRAME SRC="+org.eclipse.jst.ws.util.JspUtils.markup(resultJSP.toString()) +"NAME=result  MARGINWIDTH=1 MARGINHEIGHT=1 SCROLLING=yes FRAMEBORDER=1>"
        +"</FRAMESET><NOFRAMES><BODY>The Web Services Test Client requires a browser that supports frames.</BODY>"
		+"</NOFRAMES></FRAMESET></HTML>");
	}
}
